import React from "react";

export default function LcarsCorner() {
  return (
    <div className="w-[60px] h-[60px] bg-lcars-blue rounded-tr-full" />
  );
}
