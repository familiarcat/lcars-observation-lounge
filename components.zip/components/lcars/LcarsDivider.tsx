import React from 'react';

export default function LcarsDivider() {
  return <hr className="border-lcars-orange my-2" />;
}
