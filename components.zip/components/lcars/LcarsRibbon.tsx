import React from "react";

export default function LcarsRibbon({ children }: { children: React.ReactNode }) {
  return (
    <div className="bg-lcars-peach h-[50px] rounded-full px-4 flex items-center">
      {children}
    </div>
  );
}
