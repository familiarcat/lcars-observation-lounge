import React from 'react';

export default function LcarsScannerBar() {
  return (
    <div className="h-2 w-full bg-gradient-to-r from-lcars-blue via-lcars-peach to-lcars-blue animate-pulse rounded-full mt-2" />
  );
}
